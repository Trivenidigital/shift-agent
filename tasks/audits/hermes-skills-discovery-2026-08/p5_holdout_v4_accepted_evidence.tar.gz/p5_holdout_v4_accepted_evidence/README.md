# P5 holdout-v4 — accepted evidence archive

84 integrity-verified PNGs from the **P5 holdout-v4** package (`p5_holdout_v4`,
frozen target `p5-v4-freeze-1`).

## Why this archive exists

The Hermes structured-output skills programme (P1/P3/P4/P5/P6) is **terminally closed** as of
2026-08-03 — all five workflows `REJECT_AND_RETIRE`. For P5 specifically: **the authoring
succeeded and the harness failed.** The mandatory preflight was structurally invalid before
case 1, so 0 of 54 cases executed. The PNGs themselves are sound.

The closure record explicitly says these must not be re-authored. This archive is their
durable copy, because the source tree they live in is deliberately untracked in git.

## Contents

- `p5_holdout_v4/` — the 84 accepted PNGs, byte-for-byte, unmodified
- `MANIFEST.json` — per-file relative path, SHA-256, byte size, layout, case, evidence role
- `p5_holdout_v4_manifest.json` — original authoring index: 5 layouts, 54 cases, 84 files
- `README.md` — this file

Nothing else. No generator scripts, caches, `.pyc`, rejected or intermediate PNGs.

## Evidence roles

| role | count | meaning |
|---|---|---|
| `layout_reference` | 5 | clean reference sheet for a layout |
| `delivered_edited` | 54 | the delivered/edited sheet under adjudication |
| `approved_after` | 25 | approved-after sheet an authorized change points to |

Roles are derived from the authoring manifest's `layouts[].reference_file`,
`cases[].edited_file` and `cases[].authorized_changes[].approved_after_file` — not from
filename parsing. Every one of the 84 is reachable from that structure.

## Verify

```sh
sha256sum p5_holdout_v4_accepted_evidence.tar.gz          # compare to the recorded archive hash
tar xzf p5_holdout_v4_accepted_evidence.tar.gz
cd p5_holdout_v4_accepted_evidence
python - <<'PY'
import json, hashlib, pathlib
m = json.load(open('MANIFEST.json'))
bad = [e['relative_path'] for e in m['files']
       if hashlib.sha256(pathlib.Path(e['relative_path']).read_bytes()).hexdigest() != e['sha256']]
print(f"{len(m['files']) - len(bad)}/{len(m['files'])} verified", "FAIL: " + str(bad) if bad else "OK")
PY
```

## Reuse

**Requires explicit authorization under a NEW programme.** The programme that produced these is
closed. Four known harness defects must be fixed before any reuse — see the closure block at the
top of `tasks/todo.md`.

## Determinism

Archive built with sorted entry order, uid/gid 0, empty uname/gname, all entry mtimes 0 and gzip
mtime 0. Rebuilding from the same inputs reproduces a byte-identical archive and SHA-256.
